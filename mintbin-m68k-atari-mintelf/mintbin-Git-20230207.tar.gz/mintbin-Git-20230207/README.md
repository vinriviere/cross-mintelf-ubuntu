[![Build Status](https://github.com/freemint/mintbin/actions/workflows/build.yml/badge.svg?branch=master)](https://github.com/freemint/mintbin/actions) 

Latest snapshot: [Download](https://tho-otto.de/snapshots/mintbin/mintbin-latest.tar.bz2)
