/* This header file is used in 4.3BSD to define `struct lastlog',
   which we define in <utmpbits.h>.  */

#include <utmp.h>
