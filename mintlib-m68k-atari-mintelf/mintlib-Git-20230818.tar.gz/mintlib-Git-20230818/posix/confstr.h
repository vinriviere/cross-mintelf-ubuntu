#define	CS_PATH	"/bin:/usr/bin"
