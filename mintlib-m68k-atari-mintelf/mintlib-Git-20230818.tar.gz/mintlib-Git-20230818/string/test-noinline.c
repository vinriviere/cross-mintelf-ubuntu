/* We don't want to test any of the inline functions here.  */

#define __NO_STRING_INLINES 1
#include "test-common.c"
