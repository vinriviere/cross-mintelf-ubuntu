/* Copyright (C) 1994, 1997 Free Software Foundation, Inc.
   This file is part of the GNU C Library.
   Contributed by Joel Sherrill (jsherril@redstone-emh2.army.mil),
     On-Line Applications Research Corporation.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with the GNU C Library; if not, see
   <https://www.gnu.org/licenses/>.  */

/* Modified for MiNTLib by Guido Flohr <guido@freemint.de>.  */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef __MSHORT__
# define ffs ffsl
#endif

int
main (void)
{
  int failures = 0;
  long int i;
  void try (int value, int expected)
    {
      if (ffs (value) != expected)
	{
	  fprintf (stderr, "%#x expected %d got %d\n",
		   value, expected, ffs (value));
	  ++failures;
	}
    }

  try (0, 0);
  for (i=0 ; i<32 ; i++)
    try (1<<i, i+1);
  for (i=0 ; i<32 ; i++)
    try ((~0 >> i) << i, i+1);
  try (0x80008000, 16);

  if (failures)
    printf ("Test FAILED!  %d failure%s.\n", failures, &"s"[failures == 1]);
  else
    puts ("Test succeeded.");

  exit (failures);
}
