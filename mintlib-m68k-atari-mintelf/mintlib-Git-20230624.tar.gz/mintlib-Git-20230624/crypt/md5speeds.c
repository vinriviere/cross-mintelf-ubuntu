#define MD5CRYPT
#include "speeds.c"
