/* Dummy config.h to make glibc stuff happy.  */
#include <features.h>

#define HAVE_STRING_H 1
#define STDC_HEADERS 1
#define HAVE_MEMPCPY 1
#define HAVE_DIRENT_H 1
#define HAVE_ALLOCA_H 1
#define HAVE_STDLIB_H 1
#define HAVE_LOCALTIME_R 1
