#if defined(__AHCC__) && defined(__HAVE_68881__)

#ifndef __NO_MATH_INLINES

#endif /* __NO_MATH_INLINES */

#endif
